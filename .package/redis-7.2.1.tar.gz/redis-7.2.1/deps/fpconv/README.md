libfpconv

----------------------------------------------

Fast and accurate double to string conversion based on Florian Loitsch's Grisu-algorithm[1].

This port contains a subset of the 'C' version of Fast and accurate double to string conversion based on Florian Loitsch's Grisu-algorithm available at [github.com/night-shift/fpconv](https://github.com/night-shift/fpconv)).

[1] https://www.cs.tufts.edu/~nr/cs257/archive/florian-loitsch/printf.pdf
